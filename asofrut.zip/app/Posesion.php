<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Posesion extends Model
{
    protected $table = 'posesions';
    protected $fillable = ['nombre']; 
}
